function isSearchPage(){return location.pathname.includes("/video/search")||location.search.includes("search=")}
function text(el){return (el.innerText||el.textContent||"").toLowerCase()}
function applyFilters(c){
  if(!isSearchPage()) return;
  const wanted=[c.q,...(c.extra||"").split(",").map(x=>x.trim()),c.tag].filter(Boolean).map(x=>x.toLowerCase());
  const cards=[...document.querySelectorAll("li, article, .videoBox, .pcVideoListItem, [class*="+"video"+"]")];
  if(!wanted.length && !c.quality) return;
  cards.forEach(card=>{
    const t=text(card);
    const okKeywords=wanted.every(k=>t.includes(k));
    const okQuality=!c.quality || t.includes(c.quality);
    card.style.display=(okKeywords&&okQuality)?"":"none";
  });
  // Với các bộ lọc không có phần tử tương ứng trên website, giữ nguyên URL và chỉ lọc phần tử mà extension có thể nhận diện.
  window.dispatchEvent(new CustomEvent("advanced-search-v2-applied"));
}
chrome.runtime.onMessage.addListener((m)=>{if(m?.type==="APPLY_FILTERS")applyFilters(m.config||{})});
chrome.storage.local.get("config",r=>{if(r.config)setTimeout(()=>applyFilters(r.config),800)});