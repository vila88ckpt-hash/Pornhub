const $=id=>document.getElementById(id);
const ids=["q","extra","duration","quality","date","sort","tag","site"];
function getConfig(){return Object.fromEntries(ids.map(id=>[id,$(id).type==="checkbox"?$(id).checked:$(id).value.trim()]));}
function query(c){let a=[c.q,...c.extra.split(",").map(x=>x.trim()).filter(Boolean),c.tag].filter(Boolean);return a.join(" ");}
function update(){let c=getConfig(),q=query(c);$("preview").textContent=c.site&&q?"site:pornhub.com "+q:q;}
ids.forEach(id=>$(id).addEventListener("input",update));
$("apply").onclick=()=>{let c=getConfig(),q=query(c);if(!q){$("status").textContent="Hãy nhập từ khóa.";return}let u=c.site?"https://www.google.com/search?q="+encodeURIComponent("site:pornhub.com "+q):"https://www.pornhub.com/video/search?search="+encodeURIComponent(q);chrome.tabs.create({url:u});};
$("applyCurrent").onclick=async()=>{let c=getConfig();let [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id){return}try{await chrome.tabs.sendMessage(tab.id,{type:"APPLY_FILTERS",config:c});$("status").textContent="Đã gửi bộ lọc cho trang hiện tại."}catch(e){$("status").textContent="Trang hiện tại không hỗ trợ content script."}};
$("save").onclick=async()=>{await chrome.storage.local.set({config:getConfig()});$("status").textContent="Đã lưu cấu hình."};
(async()=>{let r=await chrome.storage.local.get("config");if(r.config)ids.forEach(id=>{if(r.config[id]!==undefined){if($(id).type==="checkbox")$(id).checked=r.config[id];else $(id).value=r.config[id]}});update()})();