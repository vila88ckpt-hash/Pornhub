# Advanced Search Helper V2

Extension Manifest V3 cho Cốc Cốc/Chromium.

## Cài đặt
1. Giải nén ZIP.
2. Mở trang Extensions của Cốc Cốc.
3. Bật Developer mode nếu phiên bản Cốc Cốc của bạn cung cấp tùy chọn này.
4. Chọn Load unpacked / Tải tiện ích đã giải nén.
5. Chọn thư mục có `manifest.json`.

## Chức năng
- Từ khóa chính/phụ.
- Tag/category.
- Thời lượng, chất lượng, ngày đăng và sắp xếp trong giao diện.
- Lưu cấu hình.
- Mở truy vấn tìm kiếm.
- Gửi cấu hình cho content script trên trang hiện tại.
- Lọc các thẻ kết quả mà extension có thể nhận diện theo nội dung hiển thị.

## Lưu ý
Website có thể thay đổi HTML/class hoặc không cung cấp một số bộ lọc qua URL. Vì vậy extension chỉ tự động áp dụng được những tiêu chí mà trang hiện tại cung cấp hoặc extension nhận diện được; không giả lập quyền truy cập dữ liệu riêng tư hay vượt qua giới hạn của website.
